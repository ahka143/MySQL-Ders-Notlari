/* ========================== HASTA PROJESI =================================*/   
  CREATE TABLE if not exists hastaneler
   
    
 